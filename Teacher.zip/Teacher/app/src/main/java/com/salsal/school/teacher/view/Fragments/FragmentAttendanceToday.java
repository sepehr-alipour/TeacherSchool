package com.salsal.school.teacher.view.Fragments;

import android.support.v4.app.Fragment;

import com.salsal.school.teacher.view.BaseFragment;

/**
 * Created by Sepehr on 12/4/2017.
 */

public class FragmentAttendanceToday extends BaseFragment {
}
