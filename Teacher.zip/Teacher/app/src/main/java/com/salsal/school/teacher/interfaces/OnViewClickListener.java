package com.salsal.school.teacher.interfaces;

import android.view.View;

public interface OnViewClickListener {
    void clicked(int type, View view);
}
