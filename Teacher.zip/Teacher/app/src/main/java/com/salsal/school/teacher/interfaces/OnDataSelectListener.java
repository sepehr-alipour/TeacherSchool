package com.salsal.school.teacher.interfaces;

public interface OnDataSelectListener {

    void dataSelected(Object data);
}
