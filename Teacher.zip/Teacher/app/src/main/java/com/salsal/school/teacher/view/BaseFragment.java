package com.salsal.school.teacher.view;

import android.support.v4.app.Fragment;

public class BaseFragment extends Fragment {
}
