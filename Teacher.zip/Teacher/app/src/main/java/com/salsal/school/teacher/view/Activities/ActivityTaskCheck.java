package com.salsal.school.teacher.view.Activities;

import android.support.v7.app.AppCompatActivity;

import com.salsal.school.teacher.view.BaseActivity;

/**
 * Created by Sepehr on 12/4/2017.
 */

public class ActivityTaskCheck extends BaseActivity {
}
