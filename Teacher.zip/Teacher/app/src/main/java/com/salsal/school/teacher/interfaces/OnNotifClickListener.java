package com.salsal.school.teacher.interfaces;

import com.salsal.school.teacher.model.NotificationRes;

public interface OnNotifClickListener {

    void clicked(NotificationRes.DataBean notification);
}
